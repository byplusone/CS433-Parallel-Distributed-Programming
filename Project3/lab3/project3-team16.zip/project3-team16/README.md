#源程序列表：
CPU.cpp

Naive.cu

SharedMemory.cu

NoBankConflict.cu

LoopUnrolled.cu

#程序编译方法：
##1. cpp文件
直接在visual studio2010环境下编译即可

##2. cu文件
使用安装了CUDA套件，并且加载了CUDA库的visual studio2010环境编译即可